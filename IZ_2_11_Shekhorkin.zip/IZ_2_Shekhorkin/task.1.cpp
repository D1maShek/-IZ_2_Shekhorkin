﻿#include <iostream>
#include <cmath>

int main() {

	float f;
	float m1;
	float m2;
	float r;
	float g = 6.67 * std::pow(10, -11);

	std::cout << "m1=";
	std::cin >> m1;
	std::cout << "m2=";
	std::cin >> m2;
	std::cout << "r=";
	std::cin >> r;
	f = g * ((m1 * m2) / std::pow(r, 2));
	std::cout << f << std::endl;

	return 0;
}