﻿#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

int main() {
	std::string line;
	float a, a_2, a_4, a_9;

	std::ifstream in("in2.dat");
	if (in.is_open())
	{
		while (std::getline(in, line))
		{
			std::stringstream ss(line);
			if (ss >> a) {

				std::cout << "a" << "=" << a << std::endl;
				a_2 = a * a;
				a_4 = a_2 * a_2;
				a_9 = a_4 * a_4 * a;
	
				std::cout << "a9" << "=" << a_9 << std::endl;
			}
		}
		
	}
	in.close();
}