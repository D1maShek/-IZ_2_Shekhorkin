﻿#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

int main() {
	std::string line;
	double x;

	std::fstream in("in3.dat");
	if (in.is_open()) {

		while (std::getline(in, line)) {

			std::stringstream ss(line); 
			if (ss >> x) {

				std::cout << "x" << "=" << x << std::endl;

				double expr1 = 1 + x * (-2 + x * (3 - 4 * x));
				double expr2 = 1 + x * (2 + x * (3 + 4 * x));
				
				std::ofstream out;
				out.open("out3.dat");
				if (out.is_open()) {

					out << expr1 << std::endl;
					out << expr2 << std::endl;
				}
				out.close();
			}

		}
	}
	in.close();
}